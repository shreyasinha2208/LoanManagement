package com.cg.ibs.loanmgmt.bean;

public enum LoanType {
	HOME_LOAN, EDUCATION_LOAN, PERSONAL_LOAN, VEHICLE_LOAN

}
